"use strict";
// naam: Roel De Haes
import Product from './Product';
export default class Container{
    _products;
    _maxWeight;

    constructor(maxWeight) {
        if (typeof maxWeight != 'number')
        {
            throw "maxWeight must be number";
        }
        if ( maxWeight <= 0 )
        {
            throw "maxWeight must be a number > 0";
        }
        this._maxWeight = maxWeight;
        this._products = [];
    }

    addProduct(product)
    {
        if (! product instanceof  Product)
        {
            throw "error: not Product";
        }

        let sum = 0;
        for(let p of this._products)
        {
            if (p.id === product.id)
            {
                throw "error: id already exist"
            }
            sum += p.weight;
        }

        if (sum + product.weight >= this._maxWeight)
        {
            throw new Error("error: to heavy");
        }

        this._products.push(product);

    }

    getProductAtIndex(id)
    {
        if (! Number.isInteger(id))
        {
            throw "id must be an integer";
        }

        if ( id <= 0 )
        {
            throw "id must be an integer > 0";
        }

        if ( id > this._products.length )
        {
            throw "id can't be higher that the length of the product array";
        }

        let foundProduct;
        for(let i of this._products)
        {
            console.log(i.id + " - " + id);
            if (i.id === id)
            {
                console.log(i.id + " - " + id);
                foundProduct = i;
            }

        }

        return foundProduct;

    }
}
