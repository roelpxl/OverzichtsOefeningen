"use strict";
// naam Roel De Haes
export default class Product{
    _id;
    _weight;

    constructor(id,weight) {
        if (! Number.isInteger(id))
        {
            throw "id must be an integer";
        }
        if ( id <= 0 )
        {
            throw "id must be an integer > 0";
        }

        if (typeof weight != 'number')
        {
            throw "weight must be number";
        }
        if ( weight <= 0 )
        {
            throw "weight must be a number > 0";
        }

        this._id = id;
        this._weight = weight;
    }

    get id() {
        return this._id;
    }

    get weight() {
        return this._weight;
    }

}
