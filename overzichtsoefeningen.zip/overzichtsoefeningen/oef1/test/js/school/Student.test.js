import Course from '../../../src/js/school/Course';
import Student from '../../../src/js/school/Student';
// naam: 


test("calculateGrade moet 12 als terugkeerwaarde hebben", () =>
{
    let student=new Student(1);
    let course=new Course(101);
    course.completed=true;
    course.grade=12;
    student.addCourse(course);
    expect(student.calculateGrade()).toBe(12);
})

test("calculateGrade moet een error opwerpen", () =>
{
    expect
    (() =>
        {
            let student = new Student(1);
            let course = new Course(101);
            course.completed = false;
            course.grade = 12;
            student.addCourse(course);
            student.calculateGrade();
        }
    ).toThrow("error no courses");
})