"use strict";
// naam: Course Roel De Haes
export default class Course {
    _grade;
    _id;
    _completed;

    constructor(id)
    {
        this._id = id;
        this._grade = 0;
        this._completed = false;
    }

    get grade() {
        return this._grade;
    }

    set grade(grade) {
        this._grade = grade;
    }

    get completed() {
        return this._completed;
    }

    set completed(completed) {
        this._completed = completed;
    }

    get id() {
        return this._id;
    }

    set id(id) {
        this._id = id;
    }
}
