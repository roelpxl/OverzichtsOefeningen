"use strict";
import Course from './Course';
// naam: Roel De Haes
export default class Student
{
    _id;
    _courses;

    constructor(id) {
        this._id = id;
        this._courses = [];
    }

    addCourse(course)
    {
        if (!course instanceof Course)
        {
            //console.log("error: not Course");
            throw "error: not Course";
        }

        this._courses.push(course);
    }

    calculateGrade()
    {
        let grade = 0;
        let aantalCourses = 0;

        for(let c of this._courses)
        {
            if (c.completed)
            {
                aantalCourses += 1;
                grade += c.grade;
            }
        }

        if (aantalCourses === 0)
        {
            //console.log("error: no courses");
            throw "error no courses";
        }
        return grade / aantalCourses;
    }
}
