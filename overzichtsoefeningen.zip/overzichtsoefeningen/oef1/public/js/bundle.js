/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/js/app.js":
/*!***********************!*\
  !*** ./src/js/app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var _school_Course__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./school/Course */ \"./src/js/school/Course.js\");\n/* harmony import */ var _school_Student__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./school/Student */ \"./src/js/school/Student.js\");\n\n\n\n\n\nwindow.addEventListener(\"load\", ()=> {\n\tlet student=new _school_Student__WEBPACK_IMPORTED_MODULE_1__.default(1);\n\tlet course=new _school_Course__WEBPACK_IMPORTED_MODULE_0__.default(101);\n\tcourse.completed=true;\n\tcourse.grade=12;\n\tstudent.addCourse(course);\n\tlet course2=new _school_Course__WEBPACK_IMPORTED_MODULE_0__.default(111);\n\tcourse2.completed=true;\n\tcourse2.grade=13;\n\tstudent.addCourse(course2);\n\tlet course3=new _school_Course__WEBPACK_IMPORTED_MODULE_0__.default(121);\n\tstudent.addCourse(course3);\n\tlet grade = student.calculateGrade();\n\tdocument.getElementById(\"output\").appendChild(document.createTextNode(grade));\n\t} \n);\n\n\n\n\n//# sourceURL=webpack://oef1/./src/js/app.js?");

/***/ }),

/***/ "./src/js/school/Course.js":
/*!*********************************!*\
  !*** ./src/js/school/Course.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Course)\n/* harmony export */ });\n\n// naam: Course\nclass Course {\n    _grade;\n    _id;\n    _completed;\n\n    constructor(id)\n    {\n        this._id = id;\n        this._grade = 0;\n        this._completed = false;\n    }\n\n    get grade() {\n        return this._grade;\n    }\n\n    set grade(grade) {\n        this._grade = grade;\n    }\n\n    get completed() {\n        return this._completed;\n    }\n\n    set completed(completed) {\n        this._completed = completed;\n    }\n\n    get id() {\n        return this._id;\n    }\n\n    set id(id) {\n        this._id = id;\n    }\n}\n\n\n//# sourceURL=webpack://oef1/./src/js/school/Course.js?");

/***/ }),

/***/ "./src/js/school/Student.js":
/*!**********************************!*\
  !*** ./src/js/school/Student.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Student)\n/* harmony export */ });\n/* harmony import */ var _Course__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Course */ \"./src/js/school/Course.js\");\n\n\n// naam: \nclass Student\n{\n    _id;\n    _courses;\n\n    constructor(id) {\n        this._id = id;\n        this._courses = [];\n    }\n\n    addCourse(course)\n    {\n        if (!course instanceof _Course__WEBPACK_IMPORTED_MODULE_0__.default)\n        {\n            //console.log(\"error: not Course\");\n            throw \"error: not Course\";\n        }\n\n        this._courses.push(course);\n    }\n\n    calculateGrade()\n    {\n        let grade = 0;\n        let aantalCourses = 0;\n\n        for(let c of this._courses)\n        {\n            if (c.completed)\n            {\n                aantalCourses += 1;\n                grade += c.grade;\n            }\n        }\n\n        if (aantalCourses === 0)\n        {\n            //console.log(\"error: no courses\");\n            throw \"error no courses\";\n        }\n        return grade / aantalCourses;\n    }\n}\n\n\n//# sourceURL=webpack://oef1/./src/js/school/Student.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./src/js/app.js");
/******/ 	
/******/ })()
;